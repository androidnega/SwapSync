"""
Reset admin password to admin123
"""
from app.models.user import User, UserRole
from app.core.database import SessionLocal

db = SessionLocal()

# Find admin user
admin = db.query(User).filter(User.username == 'admin').first()

if admin:
    print(f"✅ Found admin user: {admin.username}")
    print(f"   Role: {admin.role}")
    print(f"   Email: {admin.email}")
    
    # Reset password to admin123
    admin.hashed_password = User.hash_password('admin123')
    db.commit()
    
    print("\n✅ Password reset to: admin123")
    print("\nCredentials:")
    print("  Username: admin")
    print("  Password: admin123")
    
    # Test the password
    if admin.verify_password('admin123'):
        print("\n✅ Password verification successful!")
    else:
        print("\n❌ Password verification failed!")
else:
    print("❌ Admin user not found! Creating new admin...")
    new_admin = User(
        username='admin',
        email='admin@swapsync.com',
        full_name='System Administrator',
        hashed_password=User.hash_password('admin123'),
        role=UserRole.SUPER_ADMIN,
        is_active=1
    )
    db.add(new_admin)
    db.commit()
    print("✅ Admin user created!")
    print("\nCredentials:")
    print("  Username: admin")
    print("  Password: admin123")

db.close()

