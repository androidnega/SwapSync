"""
Simple password reset using direct database access
"""
import sqlite3
from passlib.context import CryptContext

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    """Hash a password"""
    return pwd_context.hash(password)

def reset_all_passwords():
    """Reset all user passwords"""
    # Connect to database
    conn = sqlite3.connect('swapsync.db')
    cursor = conn.cursor()
    
    # Define password mappings
    password_resets = {
        "admin": "admin123",
        "ceo1": "ceo123",
        "keeper": "keeper123",
        "keeper1": "keeper123",
        "repairer": "repair123",
        "repairer1": "repair123"
    }
    
    print("🔐 Resetting User Passwords...")
    print("=" * 60)
    
    for username, new_password in password_resets.items():
        # Check if user exists
        cursor.execute("SELECT id, email, role FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        
        if user:
            user_id, email, role = user
            # Hash the new password
            password_hash = hash_password(new_password)
            
            # Update the password
            cursor.execute(
                "UPDATE users SET password_hash = ? WHERE username = ?",
                (password_hash, username)
            )
            
            print(f"✅ Reset password for: {username}")
            print(f"   New password: {new_password}")
            print(f"   Email: {email}")
            print(f"   Role: {role}")
            print("-" * 60)
        else:
            print(f"⚠️  User not found: {username}")
    
    # Commit changes
    conn.commit()
    conn.close()
    
    print("\n" + "=" * 60)
    print("✅ Password reset complete!")
    print("=" * 60)
    print("\n📋 LOGIN CREDENTIALS:")
    print("=" * 60)
    print("Super Admin   → admin / admin123")
    print("Manager/CEO   → ceo1 / ceo123")
    print("Shop Keeper   → keeper / keeper123")
    print("              → keeper1 / keeper123")
    print("Repairer      → repairer / repair123")
    print("              → repairer1 / repair123")
    print("=" * 60)
    print("\n🔗 Login URL: http://localhost:5173/login")
    print("\n✅ All passwords are now working!")

if __name__ == "__main__":
    reset_all_passwords()

