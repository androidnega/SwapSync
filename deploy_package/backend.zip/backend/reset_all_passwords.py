"""
Reset all user passwords to ensure they work correctly
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy.orm import Session
from app.core.database import SessionLocal, engine
from app.models.user import User

def reset_passwords():
    """Reset all user passwords to known values"""
    db: Session = SessionLocal()
    
    try:
        # Define password mappings
        password_resets = {
            "admin": "admin123",
            "ceo1": "ceo123",
            "keeper": "keeper123",
            "keeper1": "keeper123",
            "repairer": "repair123",
            "repairer1": "repair123"
        }
        
        print("🔐 Resetting User Passwords...")
        print("=" * 60)
        
        for username, new_password in password_resets.items():
            user = db.query(User).filter(User.username == username).first()
            
            if user:
                # Hash and set new password
                user.password_hash = User.hash_password(new_password)
                db.commit()
                print(f"✅ Reset password for: {username}")
                print(f"   New password: {new_password}")
                print(f"   Email: {user.email}")
                print(f"   Role: {user.role}")
                print("-" * 60)
            else:
                print(f"⚠️  User not found: {username}")
        
        print("\n" + "=" * 60)
        print("✅ Password reset complete!")
        print("=" * 60)
        print("\n📋 LOGIN CREDENTIALS:")
        print("=" * 60)
        print("Super Admin   → admin / admin123")
        print("Manager/CEO   → ceo1 / ceo123")
        print("Shop Keeper   → keeper / keeper123")
        print("              → keeper1 / keeper123")
        print("Repairer      → repairer / repair123")
        print("              → repairer1 / repair123")
        print("=" * 60)
        
    except Exception as e:
        print(f"❌ Error resetting passwords: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    reset_passwords()

