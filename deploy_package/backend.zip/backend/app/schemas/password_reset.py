"""
Pydantic schemas for Password Reset
"""
from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime


class PasswordResetRequest(BaseModel):
    """Schema for requesting password reset"""
    username: str
    phone_number: str
    email: EmailStr


class PasswordResetVerify(BaseModel):
    """Schema for verifying password reset"""
    reset_token: str


class PasswordResetComplete(BaseModel):
    """Schema for completing password reset"""
    reset_token: str
    new_password: str


class PasswordResetResponse(BaseModel):
    """Schema for password reset response"""
    id: int
    user_id: int
    is_verified: bool
    is_used: bool
    created_at: datetime
    expires_at: datetime

    class Config:
        from_attributes = True


class AdminPasswordGenerate(BaseModel):
    """Schema for admin generating password for user"""
    user_id: int
    requested_by: str  # 'admin' or 'manager'


