"""
Password Reset Request Model
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
from app.core.database import Base
import secrets


class PasswordResetRequest(Base):
    """
    Track password reset requests with phone/email verification
    """
    __tablename__ = "password_reset_requests"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    reset_token = Column(String, unique=True, nullable=False, index=True)
    phone_number = Column(String, nullable=False)  # For verification
    email = Column(String, nullable=False)  # For verification
    is_verified = Column(Boolean, default=False)
    is_used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    verified_at = Column(DateTime, nullable=True)
    used_at = Column(DateTime, nullable=True)
    requested_by_role = Column(String, nullable=False)  # admin, manager, or self
    
    # Relationships
    user = relationship("User", backref="password_reset_requests")

    def __repr__(self):
        return f"<PasswordResetRequest(id={self.id}, user_id={self.user_id}, verified={self.is_verified})>"
    
    @staticmethod
    def generate_reset_token():
        """Generate a secure random token"""
        return secrets.token_urlsafe(32)
    
    def is_expired(self):
        """Check if the reset token is expired"""
        return datetime.utcnow() > self.expires_at
    
    def can_be_used(self):
        """Check if the reset token can be used"""
        return self.is_verified and not self.is_used and not self.is_expired()


