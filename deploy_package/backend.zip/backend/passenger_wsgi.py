"""
Passenger WSGI Entry Point for cPanel Deployment
SwapSync FastAPI Application
"""
import sys
import os

# Add the backend directory to Python path
INTERP = os.path.join(os.environ['HOME'], 'virtualenv', 'swapsync_backend', '3.9', 'bin', 'python3')
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

# Import the FastAPI application
from main import app as application

# This is required for Passenger
if __name__ == "__main__":
    application()

